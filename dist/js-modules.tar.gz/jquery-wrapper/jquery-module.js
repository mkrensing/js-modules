import * as jQuery from 'jquery-internal';
export default window.jQuery.noConflict(true)