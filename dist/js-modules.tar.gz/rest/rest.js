import { RestClient } from './client.js'

var rest = {
  name: 'rest.js',
  version: '1.0.0',
  RestClient: RestClient
}

export default rest